﻿#include <iostream>
#include <vector>

using namespace std;

struct emotion {
    int value;
    string name;
};

struct world {
    bool isLocked;
    string name;
};

vector<emotion> emotions = { {50, "joy"}, {50, "sadness"}, {50, "power"}, {50, "fear"}, {50, "calm"}, {50, "anger"}};
vector<world> worlds = { {false, "joy"}, {false, "sadness"}, {false, "power"}, {false, "fear"}, {false, "calm"}, {false, "anger"}};
//сначала - стабильное, потом emotions.size() естественных, потом 3 искуственных, потом усталость
vector<string> states = {"stable", "tense", "happy", "depressed", "undisturbed", "anxious", "relieved", "furious", "euphoric", "needmore", "tired"};

int curWrld = 1;
int curState = 0;
int minEmotion = 2;
int maxEmotion = 98;
int dominantChange = 5;
int passiveChange = 2;
int minStable = 40;
int maxStable = 60;
int minTense = 30;
int maxTense = 70;
int slowEmoDown = 20;
int slowEmoUp = 80;
int countEmotions = emotions.size();

int pairedNum(int num) {
    //возвращает парную эмоцию/мир
    return num - (2 * (num % 2) - 1);
}

float emotionMultiplier(int plusMinus, int emoNum) {
    float emoMultiplier = 0.25;
    return 1 + emoMultiplier * plusMinus * (emotions[emoNum].value < 40 || emotions[emoNum].value > 60) + emoMultiplier * plusMinus * (curState - 2 == emoNum);
}

void worldLock() {
    //блокирует миры
    for (int i = 0; i < countEmotions; i += 2) {
        if (emotions[i].value < minEmotion || emotions[i].value > maxEmotion) {
            worlds[i].isLocked = worlds[pairedNum(i)].isLocked = true;
            cout << "Worlds " << worlds[i].name << " and " << worlds[pairedNum(i)].name << " are now locked\n";
            int newWrld = i;
            while (newWrld == i || newWrld == pairedNum(i)) {
                newWrld = rand() % countEmotions;
                if (newWrld != i && newWrld != pairedNum(i)) {
                    cout << "You are ejected into " << worlds[newWrld].name << " world\n";
                }
            }
        }
    }
}

void changeEmotion() {
    //изменяет эмоцию (замена диалогу)
    cout << "Choose an emotion to change\n";
    string chosenEmo;
    cin >> chosenEmo;
    for (int i = 0; i < countEmotions; i++) {
        if (emotions[i].name == chosenEmo) {
            int changeTo = 0;
            while (changeTo != 1 && changeTo != 2) {
                cout << "1 - raise or 2 - lower?\n";
                cin >> changeTo;
                if ((changeTo == 1 || changeTo == 2) && (states[curState] != "euphoric" && states[curState] != "needmore")) {
                    emotions[i].value += dominantChange * (3 - changeTo * 2) * emotionMultiplier(- 3 + changeTo * 2, i);
                    emotions[pairedNum(i)].value = minEmotion + maxEmotion - emotions[i].value; //парные эмоции в сумме дают 100
                    for (int j = 0; j < countEmotions; j++) {
                        if (j != i && j != pairedNum(i) && j % 2 == i % 2) {
                            emotions[j].value += passiveChange * (3 - changeTo * 2) * emotionMultiplier(- 3 + changeTo * 2, j);
                            emotions[pairedNum(j)].value = minEmotion + maxEmotion - emotions[j].value;
                        }
                    }
                }
                else if (states[curState] == "euphoric" || states[curState] == "needmore") {
                    cout << "You cannot emote, you are high\n";
                }
            }
            break;
        }
        else if (i == countEmotions - 1) {
            cout << "Not an emotion\n";
        }
    }
}

void changeToTense() {
    for (int i = 0; i < countEmotions; i++) {
        if (emotions[i].value > maxStable || emotions[i].value < minStable) {
            curState = 1;
            break;
        }
    }
}

void changeNaturalState() {
    //переход в естественные состояния из напряжённого
    int worstScale = 0;
    int natState = 0;
    for (int i = 0; i < countEmotions; i++) {
        if ((emotions[i].value > maxTense || emotions[i].value < minTense) && abs(50 - emotions[i].value) >= worstScale) {
            worstScale = abs(50 - emotions[i].value);
            natState = i;
        }
    }
    if (natState != 0) {
        curState = natState + 2;
    }
}

void printInfo() {
    //печатает информацию
    cout << "You are in " << worlds[curWrld].name << " world\n";
    cout << "Your emotions:\n";
    for (int i = 0; i < countEmotions; i++) {
        cout << emotions[i].name << " - " << emotions[i].value << "\n";
    }
    cout << "Your state - " << states[curState] << "\n";
}

void changeToTired() {
    //условия для перехода в состояние усталости (из естественных)
    if (curState > 1 && curState <= countEmotions + 1) {
        int choice = 3;
        if (emotions[curState].value > 60 || emotions[curState].value < 40) {
            while (choice != 1 && choice != 2) {
                cout << "End this state? 1 - yes or 2 - no\n";
                cin >> choice;
            }
        }
        else {
            cout << "The state has ended\n";
            choice = 1;
        }
        if (choice == 1) {
            curState = states.size() - 1;
        }
    }
}

int scaleDeath() {
    //считает, сколько шкал провалено, и корректирует их
    int deathCount = 0;
    for (int i = 0; i < countEmotions; i++) {
        if (emotions[i].value < minEmotion || emotions[i].value > maxEmotion) {
            deathCount++;
            emotions[i].value = minEmotion * (emotions[i].value < minEmotion) + maxEmotion * (emotions[i].value > maxEmotion);
        }
    }
    return deathCount;
}

void drugJourney() {
    //переход в искусственные состояния (можно разбить на несколько функций)
    if (curState <= countEmotions + 1 || states[curState] == "tired") {
        int choice = 3;
        while (choice != 1 && choice != 2) {
            cout << "Would you like drugs? 1 - yes or 2 - no\n";
            cin >> choice;
        }
        if (choice == 1) {
            curState = countEmotions + 2;
            for (int i = 0; i < countEmotions; i++) {
                emotions[i].value = 50;
            }
        }
    }
    else if (curState == countEmotions + 2) { //если эйфория (переход к ломке)
        curState += 1;
        for (int i = 0; i < countEmotions; i++) {
            emotions[i].value = rand() % maxEmotion + 1;
        }
    }
    else if (curState == countEmotions + 3) { //если ломка (переход к усталости)
        curState += 1;
    }
}

int main() {
    while (true) {
        //функций смены и разблокировки миров тут нет
        printInfo();
        drugJourney();
        changeToTired();
        changeEmotion();
        if (states[curState] == "stable") {
            changeToTense();
        }
        changeNaturalState();
        worldLock();
        if (scaleDeath() == countEmotions) {
            break;
        }
    }
}
